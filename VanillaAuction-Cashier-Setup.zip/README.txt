﻿Vanilla Auction Suite - Official Release
========================================
Version: 1.0.0
Publisher: Vanilla Auction Ltd
Security: Digitally signed binary with Authenticode SHA256 & RFC3161 Timestamp.

INSTALLATION:
1. Run the Setup executable to install the application.
2. If Windows SmartScreen prompts on first run, click 'More info' -> 'Run anyway'.
3. For portable execution without installation, extract the Portable ZIP.
